module.exports = {
  name: 'Enlite Starter',
  desc: 'Enlite Starter - React.js Fullstack Template',
  prefix: 'enlite',
  footerText: 'Enlite Starter All Rights Reserved 2020',
  logoText: 'Enlite Starter',
};
